os.execute("chmod +x /var/local/payload.sh")
os.execute("echo \"\nHELLO=\\$( /var/local/payload.sh )\" >> /var/local/system/mntus.params")
os.execute("lipc-set-prop com.lab126.contentpackd rebootDevice 1")